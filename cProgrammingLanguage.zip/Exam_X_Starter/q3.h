#pragma once

#define MAX_LEN 101

typedef struct
{
	char	name[MAX_LEN];
	int		parameters;
}Course;

const char* title[4];


void q3();
Course* createCourseArr(const char* fileName, int* pSize);
void printCourseArr(const Course* arr, int size);
void printCourse(const Course* cour);