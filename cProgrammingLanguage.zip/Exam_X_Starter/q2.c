#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

#include "q2.h"

#define R 6
#define C 7

void q2()
{

	double mat[R][C] = { {1.2,	-3.1,	4.5 ,	0,		-17.6,	-3.0,	99.1},
						{6.2,	-6.1,	14.5 ,	10,		-1.6,	-3.1,	9.1},
						{5.2,	-5.1,	4.9 ,	20.1,	-2.6,	-3.5,	-99.1},
						{3.2,	-3.2,	-4.5 ,	11.5,	-2.7,	-3.9,	18.1},
						{7.2,	-3.9,	41.7 ,	-3.4,	-1.6,	-13.22,	19.56},
						{9.2,	-3.11,	41.5 ,	-11.1,	1.6,	-63.9,	19.57} };

	sortMatOfDoubles((double*)mat, R, C);
	printMat((double*)mat, R, C);

	int rIndex, cIndex, smallRows, smallCols;
	printf("Please insert row index, col index, number of rows,  and number of cols\n");
	scanf("%d %d %d %d", &rIndex, &cIndex, &smallRows, &smallCols);
	int res = printInnerMatrix((double*)mat, R, C, rIndex, cIndex, smallRows, smallCols);
	if (res == 0)
		printf("Invalid parameters\n");
}


void sortMatOfDoubles(double* mat, int rows, int cols)
{
	qsort(mat, rows * cols, sizeof(double), compareDouble);
}

int printInnerMatrix(const double* mat, int rows, int cols,
	int rowIndex, int colIndex, int smallRows, int smallCols)
{
	if (rowIndex < 0 || rowIndex >= rows)
		return 0;

	if (colIndex < 0 || colIndex >= cols)
		return 0;

	if ((colIndex + smallCols) > cols)
		return 0;

	if ((rowIndex + smallRows) > rows)
		return 0;


	const double* start = mat + rowIndex * cols + colIndex;
	for (int i = 0; i < smallRows; i++)
	{
		for (int j = 0; j < smallCols; j++)
			printf("%10.2lf", *(start + j));
		printf("\n");
		start += cols;
	}
	return 1;
}


int compareDouble(const void* val1, const void* val2)
{
	double v1 = *((const double*)val1);
	double v2 = *((const double*)val2);

	if (v1 > v2)
		return 1;
	if (v1 < v2)
		return -1;
	return 0;
}

void printMat(const double* mat, int rows, int cols)
{
	printf("Matrix is %d*%d\n", rows, cols);
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			printf("%10.2lf", *mat);
			mat++;
		}
		printf("\n");
	}
}
