#pragma once


void q2();


void printMat(const double* mat, int rows, int cols);
void sortMatOfDoubles(const double* mat, int rows, int cols);
int compareDouble(const void* val1, const void* val2);
int printInnerMatrix(const double* mat, int rows, int cols,
int rowIndex, int colIndex, int smallRows, int smallCols);