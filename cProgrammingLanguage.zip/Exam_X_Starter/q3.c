#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "q3.h"

#define FILE_NAME "afeka.txt"
 const char* title[4] = { "Hand writing","Computer Lab", "Oral Exam", "Project" };

void q3()
{
	int pSize;
	Course* coursArr = createCourseArr(FILE_NAME, &pSize);
	if (!coursArr)
	{
		printf("Error in creating the array\n");
		return;
	}

	printCourseArr(coursArr, pSize);
	free(coursArr);

}

Course* createCourseArr(const char* fileName, int* pSize)
{
	 
	Course* arrCourses; 
	int countCourse = 0;
	FILE* fp = fopen(fileName, "r"); //open file to read
	if (!fp)
	{
		printf("cannot open the file to read \n");
		return NULL;
	}

	fscanf(fp, "%d", &countCourse); //save the number of courses from the file to the countCourses;
	arrCourses = (Course*)malloc(countCourse * sizeof(Course));
	if (!arrCourses)
	{
		fclose(fp);
		return NULL;
	}
	for (int i = 0; i < countCourse; i++)
	{
		fscanf(fp, "%s", arrCourses[i].name);
		fscanf(fp, "%d", &arrCourses[i].parameters); //save the paramter for each 
	}
	fclose(fp);
	*pSize = countCourse;
	return arrCourses;


}


void printCourseArr(const Course* arr, int size)
{
	printf("There are %d courses\n", size);
	 for (int i = 0; i < size; i++)
	{
		 printCourse(&arr[i]);
		 printf("\n-----------------\n");

	}




}

void printCourse(const Course* cour)
{
	int givA, givB, givSem, weight, passing;
	int  typeexam;
	givSem = (cour->parameters >> 16) & 0x1;
	givB = (cour->parameters >> 15) & 0x1;
	givA = (cour->parameters >> 14) & 0x1;
	weight = (cour->parameters >> 9) & 0x1F;
	typeexam = (cour->parameters >> 7) & 0x3;
	passing = cour->parameters & 0x7F;

	printf("Name: %s\n", cour->name);
	printf("Given in semster A: %d\n", givA);
	printf("Given in semster B: %d\n", givB);
	printf("Given in semster summer: %d\n", givSem);
	printf("Home work weight %d percent\n", weight);
	printf("Exam type: %s\n", title[typeexam]);
	printf("Passing grade %d", passing);




}
