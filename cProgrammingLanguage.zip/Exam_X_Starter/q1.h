#pragma once

void q1();




char** createArrOfStr(char** arr, int size, int* pNewLength, int (*isGood)(const char*));
void printStrArr(const char** arr, int size);
int isFirstUpLastDown(const char* string);
int isMoreThan2Words(const char* string);
void freeStrArr(char** arr, int size);