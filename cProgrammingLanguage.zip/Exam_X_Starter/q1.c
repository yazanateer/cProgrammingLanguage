#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "q1.h"


void q1()
{
	
	char* arr[] = { "good morning israel", "Hello world" , "Funny", "fist time",
				"This is a good day" };
	int size = sizeof(arr) / sizeof(arr[0]);
	int newLength;
	char** newStrArr = createArrOfStr(arr, size, &newLength, isMoreThan2Words);
	puts("Strings with more than 2 words");
	if (newStrArr != NULL)
	{
		printStrArr(newStrArr, newLength);
		freeStrArr(newStrArr, newLength);
	}
	
	puts("Strings with first up last down");
		
	char** newStrArr1 = createArrOfStr(arr, size, &newLength, isFirstUpLastDown);
	if (newStrArr1 != NULL)
	{
		printStrArr(newStrArr1, newLength);
		freeStrArr(newStrArr1, newLength);
	}
		
		
		
		
	puts("Base strings array");
	printStrArr(arr, size);
		
		
			
			
}


char** createArrOfStr(char** arr, int size, int* pNewLength,int (*isGood)(const char*))
{
	char** finalArrString;
	int count = 0;
	char* tmep = (char*)malloc(size * sizeof(char));
	
	for (int i = 0; i < size; i++)
	{
		if (isGood(arr[i]) == 1)
			count++;
	}
	*pNewLength = count;
	if (count == 0)
		return NULL;
	 finalArrString = (char**)malloc(count* sizeof(char*));
	if (!finalArrString)
		return NULL;

	int index = 0;
	for (int i = 0; i < size; i++)
	{
		if ((isGood(arr[i])) == 1)
		{
			finalArrString[index] = _strdup(arr[i]);
			index++;
		}
	}

	return finalArrString;

}



void printStrArr(const char** arr, int size)
{
	for (int i = 0; i < size; i++)
		puts(arr[i]);
	printf("\n-----------------------------\n");
}
int isMoreThan2Words(const char* string)
{
	char* temp = _strdup(string);
	int count = 0;
	char* word = strtok(temp, " ");
	while (word != NULL)
	{
		count++;
		word = strtok(NULL, " ");
	}
	free(temp);

	return count > 2 ? 1 : 0;

}
int isFirstUpLastDown(const char* string)
{
	int len = (int)strlen(string);
	int isFirstUp = (isupper(string[0]));
	int isLastDown = islower((string[len-1]));
	return (isFirstUp && isLastDown) ? 1 : 0;

 
}

void freeStrArr(char** arr, int size)
{
	for (int i = 0; i < size; i++)
		free(arr[i]);
	free(arr);
}