#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "q1.h"
#include "q2.h"
#include "q3.h"




void main()
{
	printf("\n----------- Q1 --------\n");
	q1();
	printf("\n----------- Q2 --------\n");
	q2();
	printf("\n----------- Q3 --------\n");
	q3();
	

	system("pause");
}